#define ASKFORWORK 1000
#define WORK 2000
#define RESULT 3000
#define DONE 4000
